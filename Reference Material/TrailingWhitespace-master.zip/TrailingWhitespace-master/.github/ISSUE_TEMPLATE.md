### Installed product versions
- Visual Studio: [example 2015 Professional]
- This extension: [example 1.1.21]

### Description
Replace this text with a short description

### Steps to recreate
1. Replace this
2. text with 
3. the steps
4. to recreate

### Current behavior
Explain what it's doing and why it's wrong

### Expected behavior
Explain what it should be doing after it's fixed.